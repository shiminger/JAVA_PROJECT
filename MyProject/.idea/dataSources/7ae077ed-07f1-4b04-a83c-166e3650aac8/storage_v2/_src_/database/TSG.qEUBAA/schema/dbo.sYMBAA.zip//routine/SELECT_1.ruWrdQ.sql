create proc SELECT_1
as
begin
  select lend.reader_id,book.name,lend.Lendtime
  from lend left join book on lend.book_id = book.id
  where lend.Lendtime between '2022/01/01' and '2023/10/16' and lend.returntime is null
end
go

