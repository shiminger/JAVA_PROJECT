

create trigger t1 on lend
for delete
as
begin
   if(select reader.rtype
      from reader ,deleted
	  where reader.id = deleted.reader_id) = '教师'
   begin
      print '该记录用户为教师，不可删除'
	  rollback
   end
end

go

