create trigger t4 on reader
after update
as
begin
   if update(name)
   begin
   print '不允许修改读者姓名'
   rollback
   end
   else
   begin
   commit
   end
end
go

