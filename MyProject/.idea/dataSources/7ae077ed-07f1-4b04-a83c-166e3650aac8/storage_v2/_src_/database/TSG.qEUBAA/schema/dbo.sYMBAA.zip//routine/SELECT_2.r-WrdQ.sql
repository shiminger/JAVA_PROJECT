create proc SELECT_2 
   @sno int,@sname varchar(30),@booknum int
as
begin
  select lend.reader_id,reader.name,count( distinct lend.reader_id) as count
  from lend left join reader on reader.id = lend.reader_id
  where lend.Lendtime between '2022/01/01' and '2023/10/16' and reader.depart='计算机'
  group by lend.reader_id,reader.name
end
go

